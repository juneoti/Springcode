package com.mokcoding.mysite.service;

import com.mokcoding.mysite.domain.AttachDTO;

public interface AttachService {
	
    AttachDTO getAttachById(int attachId);

}
