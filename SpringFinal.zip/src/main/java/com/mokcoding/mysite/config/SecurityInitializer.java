package com.mokcoding.mysite.config;

import org.springframework.security.web.context.AbstractSecurityWebApplicationInitializer;

// Spring Security를 초기화하고 Spring Security를 웹 애플리케이션에 연결하는 클래스
public class SecurityInitializer extends AbstractSecurityWebApplicationInitializer{
	

}
